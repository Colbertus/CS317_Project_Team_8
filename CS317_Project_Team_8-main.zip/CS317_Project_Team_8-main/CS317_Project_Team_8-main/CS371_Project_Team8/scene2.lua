local composer = require("composer")
local scene = composer.newScene()
local physics = require("physics")
local widget = require("widget")
physics.start()
local enemy = require("enemy")
local enemy1 = require("enemy1")
local enemy2 = require("enemy2")
physics.setGravity(0,0);

-- The scene create function
-- Instantiate both background images, runtime, and the scroll speed of the background images
-- Instantiate the hp at 5 and the score at 0 
----------------------------------------
function scene:create(event)
	local timer = 0 
	local score = 0 
	local hp = 5
	local hpText
	local sceneGroup = self.view
	local bg1
	local bg2
	local runtime = 0
	local scrollSpeed = 5
	local scrollSpeed2 = 1
	group = display.newGroup() -- create group for boss
	group.anchorChildren = true 

-- boss

	local opt =
	{
		frames = {
			{ x = 16, y = 0, width = 175, height = 64}, -- 1. mainbody
			{ x = 206, y = 0, width = 21, height = 59}, -- 2. nose1
			{ x = 225, y = 0, width = 21, height = 59}, -- 3. nose2
			{ x = 246, y = 0, width = 21, height = 59}, -- 4. nose3
			{ x = 278, y = 0, width = 62, height = 59}, -- 5. mouth1
			{ x = 341, y = 0, width = 62, height = 59}, -- 6. mouth2
			{ x = 405, y = 0, width = 62, height = 59}, -- 7. mouth3
			{ x = 16, y = 80, width = 62, height = 59}, -- 8. pectoralfin1
			{ x = 76, y = 80, width = 62, height = 59}, -- 9. pectoralfin2
			{ x = 137, y = 80, width = 62, height = 59}, -- 10. pectoralfin3
			{ x = 201, y = 63, width = 62, height = 105}, -- 11. caudalfin1
			{ x = 261, y = 63, width = 62, height = 105}, -- 12. caudalfin2
			{ x = 329, y = 63, width = 62, height = 105}, -- 13. caudalfin3
			{ x = 401, y = 83, width = 67, height = 64} -- 14. dorsalfin
		}
	}
	local sheet = graphics.newImageSheet( "KingBayonet.png", opt);


-- border to make projectiles despawn

	local right = display.newRect(display.contentWidth+70, 0,20,display.contentHeight);
	right.anchorX = 0; right.anchorY = 0;
	physics.addBody( right, "static" );

-- player
	local player = display.newRect(300, 300, 50, 50)
	player:setFillColor(3, 2, 1)

	physics.addBody (player, "dynamic");

	local controlBar = display.newRect (20, display.contentCenterY, 150, display.contentHeight);
	controlBar:setFillColor(1,1,1,0.5);

-- player control
	local function move ( event )
		 if event.phase == "began" then		
			player.markY = player.y 
		 elseif event.phase == "moved" then	 	
		 	local y = (event.y - event.yStart) + player.markY	 	
		 	
		 	if (y <= 20 + player.height/2) then
			   player.y = 20+player.height/2;
			elseif (y >= display.contentHeight-20-player.height/2) then
			   player.y = display.contentHeight-20-player.height/2;
			else
			   player.y = y;		
			end

		 end
	end
	controlBar:addEventListener("touch", move);

-- Projectile 
	local cnt = 0;
	local function fire (event) 
	  if (cnt < 3) then
	    cnt = cnt+1;
		local p = display.newCircle (player.x+75, player.y, 20);
		p.anchorX = 1;
		p:setFillColor(0,1,0);
		physics.addBody (p, "dynamic", {radius=5} );
		p:applyForce(2, 0, p.x, p.y);

		--audio.play( soundTable["shootSound"] );

		local function removeProjectile (event)
	      if (event.phase=="began") then
		   	 event.target:removeSelf();
	         event.target=nil;
	         cnt = cnt - 1;

	         if (event.other.tag == "enemy") then

	         	event.other.pp:hit();
	         	
	         end
	      end
	    end
	    p:addEventListener("collision", removeProjectile);
	  end
	end

	Runtime:addEventListener("tap", fire)

-- player collision

		local function playerCollision (event)
	      if (event.phase=="began") then
		   	if(hp > 0) then
		   	hp = hp - 1
		   	hpText:removeSelf();
		    hpText=nil;
	      	hpText = display.newText("HP: "..hp, display.contentCenterX + 400, display.statusBarHeight, native.systemFont, 35)
	        end
	      	if (hp == 0) then

	      		gameOverText = display.newText("Game Over", display.contentCenterX, display.contentCenterY, native.systemFont, 60)
	        end

	      end
	    end
	    player:addEventListener("collision", playerCollision);
	
-- Instantiate the sound table for the collistion sounds 
----------------------------------------
	local soundTable = {
		bulletToEnemy = audio.loadSound("bulletToEnemy.wav"), 
		bulletToBoss = audio.loadSound("bulletToBoss.wav"),
		enemyBullet = audio.loadSound("enemyBulletToPlayer.wav"),
		bossBullet = audio.loadSound("bossBulletToPlayer.wav")
	}

-- This function instantiates both background images for the moving background
----------------------------------------
	local function addScrollableBg()
		
		-- The first bgImage that is used with bg1 and bg2
		local bgImage = { type="image", filename="farback.png" }
		local bgImage2 = { type ="image", filename = "starfield.png" }

		-- Add First bg image (farback.png)
		bg1 = display.newRect(0, 0, display.actualContentWidth, display.contentHeight)
		sceneGroup:insert(bg1) 
		bg1.fill = bgImage
		bg1.x = display.contentCenterX
		bg1.y = display.contentCenterY

		-- Add Second bg image (farback.png)
		bg2 = display.newRect(0, 0, display.actualContentWidth, display.contentHeight)
		sceneGroup:insert(bg2)
		bg2.fill = bgImage
		bg2.x = display.contentCenterX - display.actualContentWidth
		bg2.y = display.contentCenterY
		
		-- Add Third bg image (starfield.png)
		bg3 = display.newRect(0, 0, display.actualContentWidth, display.contentHeight)
		sceneGroup:insert(bg3) 
		bg3.fill = bgImage2
		bg3.x = display.contentCenterX
		bg3.y = display.contentCenterY
		
		-- Add Fourth bg image (starfield.png) 
		bg4 = display.newRect(0, 0, display.actualContentWidth, display.contentHeight)
		sceneGroup:insert(bg4) 
		bg4.fill = bgImage2
		bg4.x = display.contentCenterX - display.actualContentWidth
		bg4.y = display.contentCenterY
		
-- Instantiate the score and hp HUD 
----------------------------------------
		local scoreText = display.newText("Score: "..score, display.contentCenterX - 300, display.statusBarHeight, native.systemFont, 35)
		hpText = display.newText("HP: "..hp, display.contentCenterX + 400, display.statusBarHeight, native.systemFont, 35)
		sceneGroup:insert(scoreText)
		sceneGroup:insert(hpText) 
		
-- Here are both the congratulation and game over messages. Put them in when the game ends
----------------------------------------
		--local congrats = display.newText("Congratulations, You Win!!", display.contentCenterX, display.contentCenterY, native.systemFont, 60)
		--sceneGroup:insert(congrats) 
		
		--local gameOver = display.newText("Game Over, You Lose!!", display.contentCenterX, display.contentCenterY, native.systemFont, 60)
		--sceneGroup:insert(gameOver)
		
	end

-- This function moves the background images horizontally and loops 
----------------------------------------
	local function moveBg(dt)
		
		if bg1.x ~= nil and bg2.x ~= nil and bg3.x ~= nil and bg4.x ~= nil then
			-- Set the scroll speeds of the backgrounds 
			bg1.x = bg1.x + scrollSpeed2 * dt
			bg2.x = bg2.x + scrollSpeed2 * dt
		
			bg3.x = bg3.x + scrollSpeed * dt
			bg4.x = bg4.x + scrollSpeed * dt
		
		
			-- Loop the backgrounds whenever they goes off the screen
			if (bg1.x - display.actualContentWidth / 2.35) > display.actualContentWidth then
				bg1.x = bg2.x - display.actualContentWidth
			end
			if (bg2.x - display.actualContentWidth / 2.35) > display.actualContentWidth then
				bg2.x = bg1.x - display.actualContentWidth
			end
		
			if (bg3.x - display.actualContentWidth / 2) > display.actualContentWidth then
				bg3.x = bg4.x - display.actualContentWidth
			end
			if (bg4.x - display.actualContentWidth / 2) > display.actualContentWidth then
				bg4.x = bg3.x - display.actualContentWidth
			end
		end
	end

-- This function is used in parallel with the moveBg function to move the background
----------------------------------------
	local function getDeltaTime()
		local temp = system.getTimer()
		local dt = (temp-runtime) / (1000/60)
		runtime = temp
		return dt
	end

-- This function calls the move function using the dt variable from the getDeltaTime function
----------------------------------------
	local function enterFrame()
		local dt = getDeltaTime()
		moveBg(dt)
	end

-- This function is what starts off the background images along with their other functions 
-- Call the init function to start moving the background
----------------------------------------
	local function init()
		addScrollableBg()
		Runtime:addEventListener("enterFrame", enterFrame)
	end

	init()
	
-- The function for when the "return" button gets pressed
----------------------------------------
	local function onPressEvent(event)
		composer.gotoScene(
            "scene1",
            {
                effect = "slideLeft",
                params = {}
            }
        )
		
		composer.removeScene("scene2")
	end 
	
-- Instantiate the "return" button for the scene 
----------------------------------------
	local returnButton = widget.newButton(
		{
			label = "Return",
			onEvent = onPressEvent,
			shape = "roundedRect", 
			width = 200,
			height = 100,
			cornerRadius = 2,
			fontSize = 30
		}
	)
	
	returnButton.x = display.contentCenterX
	returnButton.y = 70
	
	sceneGroup:insert(returnButton)
	
-- This function uses the timer variable declared in the beginning and spawns an enemy randomly after 3 seconds
-- Use this function to spawn the boss since the timer logic is there
----------------------------------------
	function enemySpawn(event)
		timer = timer + 1   
		print(timer)
		local en1 = math.random() 
		local en2 = math.random() 
		if (timer % 3 == 0 and timer < 240) then 
			if en1 < 0.5 then
				sq = enemy1:new({xPos = 1300, yPos = math.random(10, 600)})
				sq:spawn()
				sq:move()
				print("Enemy 1 spawned")
			end
		elseif (timer >= 240) then
			-- where boss will spawn
			-- putting all the Keen Bayonet parts on screen
			local mainbody = display.newImage(sheet, 1)
			local nose = display.newImage(sheet, 2)
			local mouth = display.newImage(sheet, 5)
			local pectoral = display.newImage(sheet, 8)
			local caudal = display.newImage(sheet, 11)
			local dorsal = display.newImage(sheet, 14)
			--all of this code for positioning everything into place for Bayonet
			mainbody.x = display.contentCenterX
			mainbody.y = display.contentCenterY
			mainbody.xScale = 2;
			mainbody.yScale = 2;
			nose.x = display.contentCenterX - 160;
			nose.y = display.contentCenterY + 5;
			nose.xScale = 2;
			nose.yScale = 2;
			mouth.x = display.contentCenterX - 73;
			mouth.y = display.contentCenterY + 5;
			mouth.xScale = 2;
			mouth.yScale = 2;
			pectoral.x = display.contentCenterX + 95;
			pectoral.y = display.contentCenterY + 60;
			pectoral.xScale = 2;
			pectoral.yScale = 2;
			caudal.x = display.contentCenterX + 200;
			caudal.y = display.contentCenterY - 7;
			caudal.xScale = 2;
			caudal.yScale = 2;
			dorsal.x = display.contentCenterX + 50;
			dorsal.y = display.contentCenterY - 80;
			dorsal.xScale = 2;
			dorsal.yScale = 2;
			-- add all body parts to the same group
			group:insert(mainbody)
			group:insert(nose)
			group:insert(mouth)
			group:insert(pectoral)
			group:insert(caudal)
			group:insert(dorsal)
			-- move the Bayonet around randomly
			transition.to(group, {time=1000, x=math.random(600, 1100), y=math.random(0,640)})

		end
	end 
end

-- I placed this here to see what the enemy sublasses are doing

--sq = enemy1:new({xPos = 1300, yPos = math.random(10, 600)})
-- This will need to be finished after player character is created
--tr = enemy2:new({xPos= 1300, yPos = math.random(10, 600)})
--tr:spawn();
--tr:move(); 
--sq:spawn();
--sq:move();

-- The show function of the scene
----------------------------------------
function scene:show(event)
	local sceneGroup = self.view
	local phase = event.phase
	if (phase == "will") then
	 
	elseif ( phase == "did" ) then
		spawn = timer.performWithDelay(1000, enemySpawn, 400) 
	end
end

-- The hide function of the scene 
----------------------------------------
function scene:hide(event)
	local sceneGroup = self.view
	local phase = event.phase
	if (phase == "will") then

	elseif ( phase == "did" ) then
		
	end
end

-- The destroy function of the scene 
----------------------------------------
function scene:destroy(event)
	local sceneGroup = self.view

end

-- Scene Listeners
----------------------------------------
scene:addEventListener( "create", scene )
scene:addEventListener( "show", scene )
scene:addEventListener( "hide", scene )
scene:addEventListener( "destroy", scene )

return scene